function output_stream = add_enc_tail(input_stream,P)
    output_stream = [input_stream zeros(P.codeLength,1)'];
end