MEX compile on WinXP:
=====================

C:\Tools\Math\Matlab_65\bin\win32\mex -O mexde2bi.c
